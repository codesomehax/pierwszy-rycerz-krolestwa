﻿// KarpRabin.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <climits>
#include <chrono>

#define MOD (unsigned)72057594037927931 //2^56-5
//#define MOD 72057594037927931
//#define MOD 1000000007
#define BASE 256
//#define MOD 151
//#define MOD 997

unsigned long long hash(std::string const& str, size_t const& length);

void hash_plus_one(unsigned long long& sol, char const& a, char const& b, unsigned long long const& power_mod);

std::vector<int> rabin_karp(std::string const& search, std::string const& text);




int main()
{
    auto start = std::chrono::high_resolution_clock::now();
    unsigned int N;
    std::cin >> N;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::string text, search, name,tmp;
    std::ifstream file;
    for (unsigned int i = 0; i < N; i++)
    {
        text = "";
        search = "";
        std::getline(std::cin, name);
        file.open(name);
        std::getline(std::cin, search);
        if (file.is_open())
        {
            while(std::getline(file,tmp))
            {
                text += tmp;
            }
            file.close();
        }
        else
        {
            std::cout << "Nie mozna otworzyc pliku\n";
        }
        std::vector<int>solutions=rabin_karp(search, text);
        for (auto& i : solutions)
        {
            std::cout << i << ' ';
        }
        std::cout << std::endl;
    }
    //std::cout << hash("a", 1) << " hash dla a\n";
    //std::cout << hash("b", 1) << " hash dla b\n";
    //std::cout << hash("r", 1) << " hash dla r\n";
    //std::cout << hash("abr", 3) << " hash dla abr\n";
    //std::cout << hash("bra", 3) << " hash dla bra\n";
    //std::cout << hash("rab", 3) << " hash dla rab\n";
    //unsigned long long print= hash("abr", 3);
    //hash_plus_one(print, 'a', 'a', 3);
    //std::cout << print << " hash dla z hash_plus_one bra\n";
    //hash_plus_one(print, 'b', 'b', 3);
    //std::cout << print << " hash dla z hash_plus_one rab\n";
    //std::cout << "Poszukuje abr w abrabrabr: ";
    //rabin_karp("abr", "abrabrabr");
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = stop - start;
    std::cout << "Czas trwania w sekundach: " << elapsed.count();
    return 0;
}

unsigned long long hash(std::string const& str, size_t const& length)
{
    unsigned long long sol = 0;

    for (size_t i = 0; i < length; i++)
    {
        sol *= BASE;
        sol %= MOD;
        sol += abs(str[i]);
        sol %= MOD;
    }
    return sol;

}

void hash_plus_one(unsigned long long& sol, char const& a, char const& b, unsigned long long const& power_mod)
{

    /*   std::cout << sol << " sol\n";
       std::cout << minus << " minus\n";
       std::cout << (int)a << " a\n";
       std::cout << (int)b << " b\n";*/
    sol += MOD;
    sol -= a * power_mod % MOD;
    sol *= BASE;
    sol += b;
    sol %= MOD;
}

std::vector<int> rabin_karp(std::string const& search, std::string const& text) {
    size_t i, j;
    const size_t size_of_text = text.size();
    const size_t size_of_search = search.size();
    std::vector<int> occurences;
    occurences.reserve(size_of_text);
    unsigned long long hashtext = hash(text, size_of_search);
    unsigned long long hashsearch = hash(search, size_of_search);
    bool found;
    unsigned long long minus = 1;
    for (size_t i = 1; i < size_of_search; i++)
    {
        minus *= BASE;
        minus %= MOD;
    }
    for (i = 0; i <= size_of_text - size_of_search; i++)
    {
        found = false;
        if (hashtext == hashsearch)
        {
            for (j = 0; j < size_of_search; j++)
            {
                if (text[j + i] != search[j])break;
            }

            if (j == size_of_search) found = true;
        }
        if (found) occurences.push_back(i);

        if (i < size_of_text - size_of_search) hash_plus_one(hashtext, abs(text[i]), abs(text[i + size_of_search]), minus);
    }
    return occurences;
}

// Uruchomienie programu: Ctrl + F5 lub menu Debugowanie > Uruchom bez debugowania
// Debugowanie programu: F5 lub menu Debugowanie > Rozpocznij debugowanie

// Porady dotyczące rozpoczynania pracy:
//   1. Użyj okna Eksploratora rozwiązań, aby dodać pliki i zarządzać nimi
//   2. Użyj okna programu Team Explorer, aby nawiązać połączenie z kontrolą źródła
//   3. Użyj okna Dane wyjściowe, aby sprawdzić dane wyjściowe kompilacji i inne komunikaty
//   4. Użyj okna Lista błędów, aby zobaczyć błędy
//   5. Wybierz pozycję Projekt > Dodaj nowy element, aby utworzyć nowe pliki kodu, lub wybierz pozycję Projekt > Dodaj istniejący element, aby dodać istniejące pliku kodu do projektu
//   6. Aby w przyszłości ponownie otworzyć ten projekt, przejdź do pozycji Plik > Otwórz > Projekt i wybierz plik sln
